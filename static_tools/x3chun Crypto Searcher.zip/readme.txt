
  :: x3chun's Crypto Searcher (Public Version) ::
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  What's New ?
  ~~~~~~~~~~~~
  
  2004.05.19 Version ( 97 Crypto Signatures )
  
  Yeah! Long time passed since i've released previous version of my Crypto Searcher!
  Some ppl sent me an email about this tool, where they requested new functions.
  I added only few features in this version, sorry!
  And some ppl want to know what i used, if they can scan signatures in this
  tool and requested signatures from me, but i do not write it again!
  Coz i do not like modified crypto algorithm when cracker or programmer can not scan a file properly.
  If u want to know it really, unpack this file :) easy way 
  
  But i tried to get more and more stability, using Thread when scanning a file.
  
  * Added Thread Function
  
    - The previous version of this tool can't do another thing when scanning a file,
       now can do it
       
   * Added Progress Bar
   
     - Hehe. U know what it is.
     
   * Added New 34 Signatures
   
     - very important of this tool's part. Delphi Bignum Library and another Delphi Library (-:), more and more signatures like hpc, loki
        Please trust this tools!
     
   * Tip!
   
     - The TEA Encryption and Serpent are using same signatures. If u know already TEA or Serpent, do not care of this tip, but 
     if u didn't know, the tool said TEA Encryption signatures found after scanning in a file, U must decide TEA Encryption or Serpent.
     but Serpent algorithm is rare to use.. maybe crackme used it :P not shareware
     
   * Included My Crypto Source
    
     - This source is bonus from me. No Comment! just like to call it "x3chun's CryptoSource Volume1"

  * Final Words
  
  First, Thanks to Snaker from Peid/Kanal Author. If he did not release his kanal source, this tool wasn't possible.
  Thanks to all users using this tool, regardless the bad graphic.
  This tool was coded in asm language ( MASM )
  
  * Greets (in non alphabetical order)
  
  seaofglass, vivaman, dive2code, superb86, chobocracker, dumpsky, straydog, startrak, arkanoid ( the korean reverser ! )
  ganjaman, tam, hasher, scarebytes, chendler, witeg, mackt, lise_grim, punkdude, b4d_s3c70, hitman, teddy-rogers, Libx ( my friends in the world )
  
  Contact me:
  ~~~~~~~~~~~
  Email:   x3chun@korea.com
  Website: http://x3chun.wo.to

  
  * features of previous version

  2004.02.24 Version ( 73 Crypto Signatures )

  * u can Choose Shell Extension Option

  2004.02.23 Version ( 73 Crypto Signatures )

  What's New ?
  ~~~~~~~~~~~~
  * Added dump option: 

    - This option recognizes a packer used for an executable and allows you
      to dump it and search crypto algorithms used in the file after that.

  * Added shell extension function:

    - If you want to scan a file quickly, click right mouse button on file
      and you can see the "scan with cryptosearcher" option.

  * This tool has a bug on winxp , so its recommended that, if you use winxp,
    please scan a file 2 times at least. Sorry about the inconvenience.

  2004.02.20 Version ( 73 Crypto Signatures )

  What's New ?
  ~~~~~~~~~~~~
  * Added 3 crypto signatues 
  * Added some routines 
  * Fixed minor bug
  * Deleted trash code

  First of all, I want to let you know that, this tool's signatures are based
  on peid's Kanal. I added 40 more crypto signatures and some of the search
  routines that can search for a Modified Hash. You can drag a file into dialog
  box to make it easier. Crypto searcher is part of my private tool and this
  one is Public beta version of it. You can also find the screenshots of this
  tool from my website mentioned below. Enjoy this new and cool tool! :)
  